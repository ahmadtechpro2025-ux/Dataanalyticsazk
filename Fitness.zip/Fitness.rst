.. code:: ipython3

    import pandas as pd
    import numpy as np
    import matplotlib.pyplot as plt
    import seaborn as sns

.. code:: ipython3

    df=pd.read_csv(r"C:\Users\User\Desktop\python\dailyActivity_merged.csv")

.. code:: ipython3

    df.info()


.. parsed-literal::

    <class 'pandas.DataFrame'>
    RangeIndex: 940 entries, 0 to 939
    Data columns (total 15 columns):
     #   Column                    Non-Null Count  Dtype  
    ---  ------                    --------------  -----  
     0   Id                        940 non-null    int64  
     1   ActivityDate              940 non-null    str    
     2   TotalSteps                940 non-null    int64  
     3   TotalDistance             940 non-null    float64
     4   TrackerDistance           940 non-null    float64
     5   LoggedActivitiesDistance  940 non-null    float64
     6   VeryActiveDistance        940 non-null    float64
     7   ModeratelyActiveDistance  940 non-null    float64
     8   LightActiveDistance       940 non-null    float64
     9   SedentaryActiveDistance   940 non-null    float64
     10  VeryActiveMinutes         940 non-null    int64  
     11  FairlyActiveMinutes       940 non-null    int64  
     12  LightlyActiveMinutes      940 non-null    int64  
     13  SedentaryMinutes          940 non-null    int64  
     14  Calories                  940 non-null    int64  
    dtypes: float64(7), int64(7), str(1)
    memory usage: 110.3 KB
    

.. code:: ipython3

    cols= ['Id','ActivityDate','TotalSteps','VeryActiveMinutes','FairlyActiveMinutes','LightlyActiveMinutes','SedentaryMinutes','Calories']
    df=df[cols]

.. code:: ipython3

    df




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Id</th>
          <th>ActivityDate</th>
          <th>TotalSteps</th>
          <th>VeryActiveMinutes</th>
          <th>FairlyActiveMinutes</th>
          <th>LightlyActiveMinutes</th>
          <th>SedentaryMinutes</th>
          <th>Calories</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1503960366</td>
          <td>4/12/2016</td>
          <td>13162</td>
          <td>25</td>
          <td>13</td>
          <td>328</td>
          <td>728</td>
          <td>1985</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1503960366</td>
          <td>4/13/2016</td>
          <td>10735</td>
          <td>21</td>
          <td>19</td>
          <td>217</td>
          <td>776</td>
          <td>1797</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1503960366</td>
          <td>4/14/2016</td>
          <td>10460</td>
          <td>30</td>
          <td>11</td>
          <td>181</td>
          <td>1218</td>
          <td>1776</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1503960366</td>
          <td>4/15/2016</td>
          <td>9762</td>
          <td>29</td>
          <td>34</td>
          <td>209</td>
          <td>726</td>
          <td>1745</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1503960366</td>
          <td>4/16/2016</td>
          <td>12669</td>
          <td>36</td>
          <td>10</td>
          <td>221</td>
          <td>773</td>
          <td>1863</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>935</th>
          <td>8877689391</td>
          <td>5/8/2016</td>
          <td>10686</td>
          <td>17</td>
          <td>4</td>
          <td>245</td>
          <td>1174</td>
          <td>2847</td>
        </tr>
        <tr>
          <th>936</th>
          <td>8877689391</td>
          <td>5/9/2016</td>
          <td>20226</td>
          <td>73</td>
          <td>19</td>
          <td>217</td>
          <td>1131</td>
          <td>3710</td>
        </tr>
        <tr>
          <th>937</th>
          <td>8877689391</td>
          <td>5/10/2016</td>
          <td>10733</td>
          <td>18</td>
          <td>11</td>
          <td>224</td>
          <td>1187</td>
          <td>2832</td>
        </tr>
        <tr>
          <th>938</th>
          <td>8877689391</td>
          <td>5/11/2016</td>
          <td>21420</td>
          <td>88</td>
          <td>12</td>
          <td>213</td>
          <td>1127</td>
          <td>3832</td>
        </tr>
        <tr>
          <th>939</th>
          <td>8877689391</td>
          <td>5/12/2016</td>
          <td>8064</td>
          <td>23</td>
          <td>1</td>
          <td>137</td>
          <td>770</td>
          <td>1849</td>
        </tr>
      </tbody>
    </table>
    <p>940 rows × 8 columns</p>
    </div>



.. code:: ipython3

    df=df.rename(columns={'ActivityDate':'Date'})

.. code:: ipython3

    df




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Id</th>
          <th>Date</th>
          <th>TotalSteps</th>
          <th>VeryActiveMinutes</th>
          <th>FairlyActiveMinutes</th>
          <th>LightlyActiveMinutes</th>
          <th>SedentaryMinutes</th>
          <th>Calories</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1503960366</td>
          <td>4/12/2016</td>
          <td>13162</td>
          <td>25</td>
          <td>13</td>
          <td>328</td>
          <td>728</td>
          <td>1985</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1503960366</td>
          <td>4/13/2016</td>
          <td>10735</td>
          <td>21</td>
          <td>19</td>
          <td>217</td>
          <td>776</td>
          <td>1797</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1503960366</td>
          <td>4/14/2016</td>
          <td>10460</td>
          <td>30</td>
          <td>11</td>
          <td>181</td>
          <td>1218</td>
          <td>1776</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1503960366</td>
          <td>4/15/2016</td>
          <td>9762</td>
          <td>29</td>
          <td>34</td>
          <td>209</td>
          <td>726</td>
          <td>1745</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1503960366</td>
          <td>4/16/2016</td>
          <td>12669</td>
          <td>36</td>
          <td>10</td>
          <td>221</td>
          <td>773</td>
          <td>1863</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>935</th>
          <td>8877689391</td>
          <td>5/8/2016</td>
          <td>10686</td>
          <td>17</td>
          <td>4</td>
          <td>245</td>
          <td>1174</td>
          <td>2847</td>
        </tr>
        <tr>
          <th>936</th>
          <td>8877689391</td>
          <td>5/9/2016</td>
          <td>20226</td>
          <td>73</td>
          <td>19</td>
          <td>217</td>
          <td>1131</td>
          <td>3710</td>
        </tr>
        <tr>
          <th>937</th>
          <td>8877689391</td>
          <td>5/10/2016</td>
          <td>10733</td>
          <td>18</td>
          <td>11</td>
          <td>224</td>
          <td>1187</td>
          <td>2832</td>
        </tr>
        <tr>
          <th>938</th>
          <td>8877689391</td>
          <td>5/11/2016</td>
          <td>21420</td>
          <td>88</td>
          <td>12</td>
          <td>213</td>
          <td>1127</td>
          <td>3832</td>
        </tr>
        <tr>
          <th>939</th>
          <td>8877689391</td>
          <td>5/12/2016</td>
          <td>8064</td>
          <td>23</td>
          <td>1</td>
          <td>137</td>
          <td>770</td>
          <td>1849</td>
        </tr>
      </tbody>
    </table>
    <p>940 rows × 8 columns</p>
    </div>



.. code:: ipython3

    df['TotalMinutes']= df.VeryActiveMinutes+df.FairlyActiveMinutes+df.SedentaryMinutes+df.LightlyActiveMinutes

.. code:: ipython3

    df['TotalHours']= df['TotalMinutes']/60

.. code:: ipython3

    df




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Id</th>
          <th>Date</th>
          <th>TotalSteps</th>
          <th>VeryActiveMinutes</th>
          <th>FairlyActiveMinutes</th>
          <th>LightlyActiveMinutes</th>
          <th>SedentaryMinutes</th>
          <th>Calories</th>
          <th>TotalMinutes</th>
          <th>TotalHours</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1503960366</td>
          <td>4/12/2016</td>
          <td>13162</td>
          <td>25</td>
          <td>13</td>
          <td>328</td>
          <td>728</td>
          <td>1985</td>
          <td>1094</td>
          <td>18.233333</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1503960366</td>
          <td>4/13/2016</td>
          <td>10735</td>
          <td>21</td>
          <td>19</td>
          <td>217</td>
          <td>776</td>
          <td>1797</td>
          <td>1033</td>
          <td>17.216667</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1503960366</td>
          <td>4/14/2016</td>
          <td>10460</td>
          <td>30</td>
          <td>11</td>
          <td>181</td>
          <td>1218</td>
          <td>1776</td>
          <td>1440</td>
          <td>24.000000</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1503960366</td>
          <td>4/15/2016</td>
          <td>9762</td>
          <td>29</td>
          <td>34</td>
          <td>209</td>
          <td>726</td>
          <td>1745</td>
          <td>998</td>
          <td>16.633333</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1503960366</td>
          <td>4/16/2016</td>
          <td>12669</td>
          <td>36</td>
          <td>10</td>
          <td>221</td>
          <td>773</td>
          <td>1863</td>
          <td>1040</td>
          <td>17.333333</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>935</th>
          <td>8877689391</td>
          <td>5/8/2016</td>
          <td>10686</td>
          <td>17</td>
          <td>4</td>
          <td>245</td>
          <td>1174</td>
          <td>2847</td>
          <td>1440</td>
          <td>24.000000</td>
        </tr>
        <tr>
          <th>936</th>
          <td>8877689391</td>
          <td>5/9/2016</td>
          <td>20226</td>
          <td>73</td>
          <td>19</td>
          <td>217</td>
          <td>1131</td>
          <td>3710</td>
          <td>1440</td>
          <td>24.000000</td>
        </tr>
        <tr>
          <th>937</th>
          <td>8877689391</td>
          <td>5/10/2016</td>
          <td>10733</td>
          <td>18</td>
          <td>11</td>
          <td>224</td>
          <td>1187</td>
          <td>2832</td>
          <td>1440</td>
          <td>24.000000</td>
        </tr>
        <tr>
          <th>938</th>
          <td>8877689391</td>
          <td>5/11/2016</td>
          <td>21420</td>
          <td>88</td>
          <td>12</td>
          <td>213</td>
          <td>1127</td>
          <td>3832</td>
          <td>1440</td>
          <td>24.000000</td>
        </tr>
        <tr>
          <th>939</th>
          <td>8877689391</td>
          <td>5/12/2016</td>
          <td>8064</td>
          <td>23</td>
          <td>1</td>
          <td>137</td>
          <td>770</td>
          <td>1849</td>
          <td>931</td>
          <td>15.516667</td>
        </tr>
      </tbody>
    </table>
    <p>940 rows × 10 columns</p>
    </div>



.. code:: ipython3

    df.Date=pd.to_datetime(df.Date)

.. code:: ipython3

    df




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Id</th>
          <th>Date</th>
          <th>TotalSteps</th>
          <th>VeryActiveMinutes</th>
          <th>FairlyActiveMinutes</th>
          <th>LightlyActiveMinutes</th>
          <th>SedentaryMinutes</th>
          <th>Calories</th>
          <th>TotalMinutes</th>
          <th>TotalHours</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1503960366</td>
          <td>2016-04-12</td>
          <td>13162</td>
          <td>25</td>
          <td>13</td>
          <td>328</td>
          <td>728</td>
          <td>1985</td>
          <td>1094</td>
          <td>18.233333</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1503960366</td>
          <td>2016-04-13</td>
          <td>10735</td>
          <td>21</td>
          <td>19</td>
          <td>217</td>
          <td>776</td>
          <td>1797</td>
          <td>1033</td>
          <td>17.216667</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1503960366</td>
          <td>2016-04-14</td>
          <td>10460</td>
          <td>30</td>
          <td>11</td>
          <td>181</td>
          <td>1218</td>
          <td>1776</td>
          <td>1440</td>
          <td>24.000000</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1503960366</td>
          <td>2016-04-15</td>
          <td>9762</td>
          <td>29</td>
          <td>34</td>
          <td>209</td>
          <td>726</td>
          <td>1745</td>
          <td>998</td>
          <td>16.633333</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1503960366</td>
          <td>2016-04-16</td>
          <td>12669</td>
          <td>36</td>
          <td>10</td>
          <td>221</td>
          <td>773</td>
          <td>1863</td>
          <td>1040</td>
          <td>17.333333</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>935</th>
          <td>8877689391</td>
          <td>2016-05-08</td>
          <td>10686</td>
          <td>17</td>
          <td>4</td>
          <td>245</td>
          <td>1174</td>
          <td>2847</td>
          <td>1440</td>
          <td>24.000000</td>
        </tr>
        <tr>
          <th>936</th>
          <td>8877689391</td>
          <td>2016-05-09</td>
          <td>20226</td>
          <td>73</td>
          <td>19</td>
          <td>217</td>
          <td>1131</td>
          <td>3710</td>
          <td>1440</td>
          <td>24.000000</td>
        </tr>
        <tr>
          <th>937</th>
          <td>8877689391</td>
          <td>2016-05-10</td>
          <td>10733</td>
          <td>18</td>
          <td>11</td>
          <td>224</td>
          <td>1187</td>
          <td>2832</td>
          <td>1440</td>
          <td>24.000000</td>
        </tr>
        <tr>
          <th>938</th>
          <td>8877689391</td>
          <td>2016-05-11</td>
          <td>21420</td>
          <td>88</td>
          <td>12</td>
          <td>213</td>
          <td>1127</td>
          <td>3832</td>
          <td>1440</td>
          <td>24.000000</td>
        </tr>
        <tr>
          <th>939</th>
          <td>8877689391</td>
          <td>2016-05-12</td>
          <td>8064</td>
          <td>23</td>
          <td>1</td>
          <td>137</td>
          <td>770</td>
          <td>1849</td>
          <td>931</td>
          <td>15.516667</td>
        </tr>
      </tbody>
    </table>
    <p>940 rows × 10 columns</p>
    </div>



.. code:: ipython3

    df.info()


.. parsed-literal::

    <class 'pandas.DataFrame'>
    RangeIndex: 940 entries, 0 to 939
    Data columns (total 10 columns):
     #   Column                Non-Null Count  Dtype         
    ---  ------                --------------  -----         
     0   Id                    940 non-null    int64         
     1   Date                  940 non-null    datetime64[us]
     2   TotalSteps            940 non-null    int64         
     3   VeryActiveMinutes     940 non-null    int64         
     4   FairlyActiveMinutes   940 non-null    int64         
     5   LightlyActiveMinutes  940 non-null    int64         
     6   SedentaryMinutes      940 non-null    int64         
     7   Calories              940 non-null    int64         
     8   TotalMinutes          940 non-null    int64         
     9   TotalHours            940 non-null    float64       
    dtypes: datetime64[us](1), float64(1), int64(8)
    memory usage: 73.6 KB
    

.. code:: ipython3

    import datetime as dt
    df['DayOfWeek']= df.Date.dt.day_name()
    

.. code:: ipython3

    df




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Id</th>
          <th>Date</th>
          <th>TotalSteps</th>
          <th>VeryActiveMinutes</th>
          <th>FairlyActiveMinutes</th>
          <th>LightlyActiveMinutes</th>
          <th>SedentaryMinutes</th>
          <th>Calories</th>
          <th>TotalMinutes</th>
          <th>TotalHours</th>
          <th>DayOfWeek</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1503960366</td>
          <td>2016-04-12</td>
          <td>13162</td>
          <td>25</td>
          <td>13</td>
          <td>328</td>
          <td>728</td>
          <td>1985</td>
          <td>1094</td>
          <td>18.233333</td>
          <td>Tuesday</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1503960366</td>
          <td>2016-04-13</td>
          <td>10735</td>
          <td>21</td>
          <td>19</td>
          <td>217</td>
          <td>776</td>
          <td>1797</td>
          <td>1033</td>
          <td>17.216667</td>
          <td>Wednesday</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1503960366</td>
          <td>2016-04-14</td>
          <td>10460</td>
          <td>30</td>
          <td>11</td>
          <td>181</td>
          <td>1218</td>
          <td>1776</td>
          <td>1440</td>
          <td>24.000000</td>
          <td>Thursday</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1503960366</td>
          <td>2016-04-15</td>
          <td>9762</td>
          <td>29</td>
          <td>34</td>
          <td>209</td>
          <td>726</td>
          <td>1745</td>
          <td>998</td>
          <td>16.633333</td>
          <td>Friday</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1503960366</td>
          <td>2016-04-16</td>
          <td>12669</td>
          <td>36</td>
          <td>10</td>
          <td>221</td>
          <td>773</td>
          <td>1863</td>
          <td>1040</td>
          <td>17.333333</td>
          <td>Saturday</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>935</th>
          <td>8877689391</td>
          <td>2016-05-08</td>
          <td>10686</td>
          <td>17</td>
          <td>4</td>
          <td>245</td>
          <td>1174</td>
          <td>2847</td>
          <td>1440</td>
          <td>24.000000</td>
          <td>Sunday</td>
        </tr>
        <tr>
          <th>936</th>
          <td>8877689391</td>
          <td>2016-05-09</td>
          <td>20226</td>
          <td>73</td>
          <td>19</td>
          <td>217</td>
          <td>1131</td>
          <td>3710</td>
          <td>1440</td>
          <td>24.000000</td>
          <td>Monday</td>
        </tr>
        <tr>
          <th>937</th>
          <td>8877689391</td>
          <td>2016-05-10</td>
          <td>10733</td>
          <td>18</td>
          <td>11</td>
          <td>224</td>
          <td>1187</td>
          <td>2832</td>
          <td>1440</td>
          <td>24.000000</td>
          <td>Tuesday</td>
        </tr>
        <tr>
          <th>938</th>
          <td>8877689391</td>
          <td>2016-05-11</td>
          <td>21420</td>
          <td>88</td>
          <td>12</td>
          <td>213</td>
          <td>1127</td>
          <td>3832</td>
          <td>1440</td>
          <td>24.000000</td>
          <td>Wednesday</td>
        </tr>
        <tr>
          <th>939</th>
          <td>8877689391</td>
          <td>2016-05-12</td>
          <td>8064</td>
          <td>23</td>
          <td>1</td>
          <td>137</td>
          <td>770</td>
          <td>1849</td>
          <td>931</td>
          <td>15.516667</td>
          <td>Thursday</td>
        </tr>
      </tbody>
    </table>
    <p>940 rows × 11 columns</p>
    </div>



.. code:: ipython3

    df.isnull().sum()




.. parsed-literal::

    Id                      0
    Date                    0
    TotalSteps              0
    VeryActiveMinutes       0
    FairlyActiveMinutes     0
    LightlyActiveMinutes    0
    SedentaryMinutes        0
    Calories                0
    TotalMinutes            0
    TotalHours              0
    DayOfWeek               0
    dtype: int64



.. code:: ipython3

    df.duplicated().sum()




.. parsed-literal::

    np.int64(0)



.. code:: ipython3

    df.describe()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Id</th>
          <th>Date</th>
          <th>TotalSteps</th>
          <th>VeryActiveMinutes</th>
          <th>FairlyActiveMinutes</th>
          <th>LightlyActiveMinutes</th>
          <th>SedentaryMinutes</th>
          <th>Calories</th>
          <th>TotalMinutes</th>
          <th>TotalHours</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>9.400000e+02</td>
          <td>940</td>
          <td>940.000000</td>
          <td>940.000000</td>
          <td>940.000000</td>
          <td>940.000000</td>
          <td>940.000000</td>
          <td>940.000000</td>
          <td>940.000000</td>
          <td>940.000000</td>
        </tr>
        <tr>
          <th>mean</th>
          <td>4.855407e+09</td>
          <td>2016-04-26 06:53:37.021276</td>
          <td>7637.910638</td>
          <td>21.164894</td>
          <td>13.564894</td>
          <td>192.812766</td>
          <td>991.210638</td>
          <td>2303.609574</td>
          <td>1218.753191</td>
          <td>20.312553</td>
        </tr>
        <tr>
          <th>min</th>
          <td>1.503960e+09</td>
          <td>2016-04-12 00:00:00</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>2.000000</td>
          <td>0.033333</td>
        </tr>
        <tr>
          <th>25%</th>
          <td>2.320127e+09</td>
          <td>2016-04-19 00:00:00</td>
          <td>3789.750000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>127.000000</td>
          <td>729.750000</td>
          <td>1828.500000</td>
          <td>989.750000</td>
          <td>16.495833</td>
        </tr>
        <tr>
          <th>50%</th>
          <td>4.445115e+09</td>
          <td>2016-04-26 00:00:00</td>
          <td>7405.500000</td>
          <td>4.000000</td>
          <td>6.000000</td>
          <td>199.000000</td>
          <td>1057.500000</td>
          <td>2134.000000</td>
          <td>1440.000000</td>
          <td>24.000000</td>
        </tr>
        <tr>
          <th>75%</th>
          <td>6.962181e+09</td>
          <td>2016-05-04 00:00:00</td>
          <td>10727.000000</td>
          <td>32.000000</td>
          <td>19.000000</td>
          <td>264.000000</td>
          <td>1229.500000</td>
          <td>2793.250000</td>
          <td>1440.000000</td>
          <td>24.000000</td>
        </tr>
        <tr>
          <th>max</th>
          <td>8.877689e+09</td>
          <td>2016-05-12 00:00:00</td>
          <td>36019.000000</td>
          <td>210.000000</td>
          <td>143.000000</td>
          <td>518.000000</td>
          <td>1440.000000</td>
          <td>4900.000000</td>
          <td>1440.000000</td>
          <td>24.000000</td>
        </tr>
        <tr>
          <th>std</th>
          <td>2.424805e+09</td>
          <td>NaN</td>
          <td>5087.150742</td>
          <td>32.844803</td>
          <td>19.987404</td>
          <td>109.174700</td>
          <td>301.267437</td>
          <td>718.166862</td>
          <td>265.931767</td>
          <td>4.432196</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    plt.figure(figsize=((6,4)))
    plt.hist(df.DayOfWeek,bins=7,color='lightskyblue',width=.6)
    plt.grid(True)
    plt.xlabel('day of week')
    plt.ylabel('freq')
    plt.title('freq by day of week')
    plt.show()



.. image:: output_18_0.png


.. code:: ipython3

    df.info()


.. parsed-literal::

    <class 'pandas.DataFrame'>
    RangeIndex: 940 entries, 0 to 939
    Data columns (total 11 columns):
     #   Column                Non-Null Count  Dtype         
    ---  ------                --------------  -----         
     0   Id                    940 non-null    int64         
     1   Date                  940 non-null    datetime64[us]
     2   TotalSteps            940 non-null    int64         
     3   VeryActiveMinutes     940 non-null    int64         
     4   FairlyActiveMinutes   940 non-null    int64         
     5   LightlyActiveMinutes  940 non-null    int64         
     6   SedentaryMinutes      940 non-null    int64         
     7   Calories              940 non-null    int64         
     8   TotalMinutes          940 non-null    int64         
     9   TotalHours            940 non-null    float64       
     10  DayOfWeek             940 non-null    str           
    dtypes: datetime64[us](1), float64(1), int64(8), str(1)
    memory usage: 80.9 KB
    

.. code:: ipython3

    sns.heatmap(df.corr(numeric_only=True))




.. parsed-literal::

    <Axes: >




.. image:: output_20_1.png


.. code:: ipython3

    plt.figure(figsize = ((8,6)))
    plt.scatter(df.TotalSteps,df.Calories ,c= df.Calories)
    plt.xlabel('steps')
    plt.ylabel('calories')
    plt.title('calories / steps relationship')
    plt.show()



.. image:: output_21_0.png


.. code:: ipython3

    plt.figure(figsize = ((8,6)))
    plt.scatter(df.TotalHours,df.Calories ,c= df.Calories)
    plt.xlabel('hours')
    plt.ylabel('calories')
    plt.title('calories / hours relationship')
    median_hours= 24
    median_calories=2134
    
    plt.axhline(median_calories,color='blue',label='median of calories')
    plt.axvline(median_hours,color='red',label='median of hours')
    
    plt.show()



.. image:: output_22_0.png


.. code:: ipython3

    very_active_minutes = df['VeryActiveMinutes'].sum()
    fairly_active_minutes = df['FairlyActiveMinutes'].sum()
    lightly_active_minutes = df['LightlyActiveMinutes'].sum()
    sedentary_minutes = df['SedentaryMinutes'].sum()
    
    minutes = [
        very_active_minutes,
        fairly_active_minutes,
        lightly_active_minutes,
        sedentary_minutes
    ]
    
    labels = [
        'Very Active',
        'Fairly Active',
        'Lightly Active',
        'Sedentary'
    ]
    
    plt.pie(minutes, labels=labels, autopct='%1.1f%%')
    plt.title('Activity Minutes Distribution')
    plt.show()



.. image:: output_23_0.png


.. code:: ipython3

    df.to_csv('Final_Fitness.csv', index=False)

